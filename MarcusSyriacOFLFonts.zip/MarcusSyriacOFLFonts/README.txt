README
Syriac Marcus font families
===========================

The Syriac Marcus fonts provide Unicode support for languages and writing systems that use the Syriac script. 

# East Syriac Marcus Regular

This font is designed for East Syriac.

# East Syriac Nohadra Regular

This font is designed for East Syriac. It is simpler a thinner typeface than East Syriac Marcus.

# AAA-Manuscript Marcus Regular

This font is designed for East Syriac. It is in a more handwritten style than the above fonts.

# Estrangelo Marcus Regular

This font is a more classical Estrangelo style.

# About

These fonts are Copyright (c) 1997-2025, Sparksoft Systems and are released under under the [SIL Open Font License (openfontlicense.org)](https://openfontlicense.org).

For a complete list of changes in this version see the FONTLOG.txt.

For copyright and licensing information - including any Reserved Font Names - see OFL.txt.

For practical information about using, modifying and redistributing this font see OFL-FAQ.txt.


